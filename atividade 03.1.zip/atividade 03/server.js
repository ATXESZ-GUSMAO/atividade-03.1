const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const fs = require('fs');
const path = require('path');

app.use(express.static(__dirname));

// Rota principal
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Função para salvar mensagem no log
function logMessage(username, message) {
  const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
  const logLine = `[${timestamp}] ${username}: ${message}\n`;
  fs.appendFile('chat.log', logLine, err => {
    if (err) console.error('Erro ao gravar no log:', err);
  });
}

// Conexão com o socket
io.on('connection', (socket) => {
  console.log('Novo usuário conectado.');

  socket.on('chat message', (data) => {
    const { username, message } = data;
    if (username && message) {
      logMessage(username, message);
      io.emit('chat message', { username, message });
    }
  });

  socket.on('disconnect', () => {
    console.log('Usuário desconectado.');
  });
});

const PORT = 3000;
http.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
